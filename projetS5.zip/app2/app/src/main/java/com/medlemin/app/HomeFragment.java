package com.medlemin.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment implements View.OnClickListener{
    globalV gv;
    String nom;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        //n=loginDoct.nomDoc;
       //  tex.setText(n);
      //  nom=gv.getNom();
        nom= ((globalV)getActivity().getApplication()).getNom();
        TextView text = (TextView) v.findViewById(R.id.drname);

        text.setText("dr."+nom);
       // id.setText(nom);
        return v;
    }

    @Override
    public void onClick(View v) {
        startActivity(new Intent(getContext(), Main3Activity.class));


    }
}
