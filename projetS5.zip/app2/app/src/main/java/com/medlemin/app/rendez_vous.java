package com.medlemin.app;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class rendez_vous extends Fragment {


    public rendez_vous() {
        // Required empty public constructor
    }
    private FloatingActionButton btrv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View vv = inflater.inflate(R.layout.fragment_rendez_vous, container, false);
        this.btrv = (FloatingActionButton) vv.findViewById(R.id.fl);
        btrv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getActivity(),newrnd.class);
                startActivity(in);
            }
        });

        return vv;
    }

}
