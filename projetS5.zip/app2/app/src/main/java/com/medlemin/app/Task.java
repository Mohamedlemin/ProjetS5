package com.medlemin.app;

public class Task {

public String nom;



    public Task(String username) {
        this.nom=username;
    }
}