package com.medlemin.app;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class profile extends Fragment {


    public profile() {
        // Required empty public constructor
    }

TextView nompaa;
    String nomp;
    globalVp vp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v= inflater.inflate(R.layout.fragment_profile, container, false);
    //   nomp=((globalVp)getActivity().getApplication()).getNomp();
//       //nompaa = (TextView)v.findViewById(R.id.nomp);
     //  nompaa.setText(vp.getNomp());

        return v;
    }

}
