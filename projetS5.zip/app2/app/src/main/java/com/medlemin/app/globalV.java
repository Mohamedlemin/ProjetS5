package com.medlemin.app;

import android.app.Application;

public class globalV extends Application {


   public String nom;
   public int id;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

