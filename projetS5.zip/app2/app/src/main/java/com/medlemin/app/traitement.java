package com.medlemin.app;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class traitement extends Fragment{



    public traitement() {
        // Required empty public constructor
    }
    private FloatingActionButton bt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v =inflater.inflate(R.layout.fragment_traitement, container, false);
        this.bt = (FloatingActionButton) v.findViewById(R.id.flt);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getActivity(),newTr.class);
                startActivity(in);
            }
        });

String[] menuitem={
        "Mohamed lemin",
        "ahmed bab",
        "Med Moctar"
};
        ListView listtr=(ListView) v.findViewById(R.id.lt);
        ArrayAdapter<String> listviewadp = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_dropdown_item_1line,
                menuitem
        );
        listtr.setAdapter(listviewadp);
        return v;
    }


}
