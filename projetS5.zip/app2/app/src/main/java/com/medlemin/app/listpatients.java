package com.medlemin.app;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class listpatients extends Fragment {


    public listpatients() {
        // Required empty public constructor
    }
  // globalV gv;
    //String nom= ((globalV)getActivity().getApplication()).getNom();

    ListView listmedcin;
    RequestQueue requestQueue;
    String urli = "https://tirispress.net/pro/listpa.php?";
    TextView textView;
    ArrayList<Task> listitems = new ArrayList<Task>();
    globalVp nomP;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("key","oncreat valid!");
        // Inflate the layout for this fragment

        final View v =inflater.inflate(R.layout.fragment_listpatients, container, false);
       final ListView  listmedcin = (ListView) v.findViewById(R.id.li);
/*
        listitems.add(new Task("Mohamed"));
        listitems.add(new Task("Ahmed"));
        listitems.add(new Task("sidi"));
        listitems.add(new Task("ali"));
        listitems.add(new Task("brahim"));
        final listAdaptter lA=new listAdaptter(listitems);
        listmedcin.setAdapter(lA);*/

listmedcin.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
       // Intent intent= new Intent(getContext(),Main3Activity.class);
        startActivity(new Intent(getContext(), Main3Activity.class));
        nomP.setNomp(listmedcin.getItemAtPosition(i).toString());
    }
});
        requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urli,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("allpa");

                            Log.d("key","try active");


                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject respons= jsonArray.getJSONObject(i);
                                String nom =respons.getString("nom");

                                Log.d("key","voici le nom "+nom);


                              listitems.add(new Task(nom));
                                listAdaptter lA=new listAdaptter(listitems);
                                listmedcin.setAdapter(lA);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("key","onErrorResponse active"+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);


        return v;
    }
/*
   public  void listAllitem(){

        listAdaptter lA=new listAdaptter(listitems);
        listmedcin.setAdapter(lA);
    }
*/





    class listAdaptter extends BaseAdapter {

        ArrayList<Task> listA = new ArrayList<Task>();

        public listAdaptter(ArrayList<Task> listA) {
            this.listA = listA;
        }

        @Override
        public int getCount() {
            return listA.size();
        }

        @Override
        public Object getItem(int position) {
            return listA.get(position).nom;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {

            LayoutInflater layoutInflater = getLayoutInflater();
            View view =layoutInflater.inflate(R.layout.llistpaitem,null);
            TextView nomeM = (TextView)view.findViewById(R.id.pan);
            nomeM.setText(listA.get(i).nom);

            return view;
        }
    }
}
