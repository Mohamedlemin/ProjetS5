package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class esp extends AppCompatActivity {
    private Button tr;
    private Button rnd;
    private Button urg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esp);


     /*   this.tr =(Button)findViewById(R.id.trt);
        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tr = new Intent(getApplicationContext(),lisTesp.class);
                startActivity(tr);
                finish();
            }
        });
        this.rnd =(Button)findViewById(R.id.rndev);
        rnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent rndvv = new Intent(getApplicationContext(),listResp.class);
                startActivity(rndvv);
                finish();
            }
        });
        this.urg =(Button)findViewById(R.id.urgeence);
        urg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent uu = new Intent(getApplicationContext(),urgence.class);
                startActivity(uu);
                finish();
            }
        });*/




    }

    public void urg(View view) {
        Intent uu = new Intent(getApplicationContext(),urgence.class);
        startActivity(uu);
        finish();
    }


    public void Rn(View view) {
        Intent rndvv = new Intent(getApplicationContext(),listResp.class);
        startActivity(rndvv);
        finish();
    }

    public void trt(View view) {

        Intent rndvv = new Intent(getApplicationContext(),listResp.class);
        startActivity(rndvv);
        finish();
    }
}
