package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
public class loginPat extends AppCompatActivity {
    Button btntst;
    TextView patnam;
    EditText logp;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pat);
        logp = (EditText) findViewById(R.id.p);
        this.btntst = (Button) findViewById(R.id.login_buttonPa);
        name = logp.getText().toString().trim();
        btntst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle b=new Bundle();


                Intent lism = new Intent(getApplicationContext(), listmed.class);
                b.putString("user",logp.getText().toString());
                lism.putExtras(b);
                startActivity(lism);
                finish();
            }
        });
    }
}
