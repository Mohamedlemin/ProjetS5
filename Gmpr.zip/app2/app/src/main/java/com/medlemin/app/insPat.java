package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class insPat extends AppCompatActivity {
    EditText nameP, usernameP, passwordP, phoneP, comenteurP, idm;
    Button btn_sendP;
    private String str_nameP, str_comenteurP, str_passwordP, str_phoneP, str_usernameP, str_idm;
    globalV gv;
    String i_d;

    String url = "https://tirispress.net/pro/insertPa.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins_pat);
        //  btn_sendP = (Button) findViewById(R.id.Pbtn_register);
        nameP = (EditText) findViewById(R.id.p_nom);

        idm = (EditText) findViewById(R.id.nome_medcin);
        comenteurP = (EditText) findViewById(R.id.p_comenteur);
        passwordP = (EditText) findViewById(R.id.p_password);
        usernameP = (EditText) findViewById(R.id.p_username);
        phoneP = (EditText) findViewById(R.id.p_phone);
        gv = (globalV) getApplicationContext();

    }

    public void Register(View view) {

/*

            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please Wait..");


            if(nameP.getText().toString().equals("")){
                Toast.makeText(this, "inserer le nom", Toast.LENGTH_SHORT).show();
            }
            else if(comenteurP.getText().toString().equals("")){
                Toast.makeText(this, "Enter commenteur", Toast.LENGTH_SHORT).show();
            }
            else if(passwordP.getText().toString().equals("")){
                Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show();
            }
            else if(phoneP.getText().toString().equals("")){
                Toast.makeText(this, "Enter le num du telephone", Toast.LENGTH_SHORT).show();
            }
            else if(usernameP.getText().toString().equals("")){
                Toast.makeText(this, "Enter username", Toast.LENGTH_SHORT).show();
            }
            else{

                progressDialog.show();

                str_nameP = nameP.getText().toString().trim();
                str_comenteurP = comenteurP.getText().toString().trim();
                str_passwordP = passwordP.getText().toString().trim();
                str_phoneP = phoneP.getText().toString().trim();
                str_usernameP  = usernameP.getText().toString().trim();
               // str_idm=idm.getText().toString().trim();

                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        nameP.setText("");
                        comenteurP.setText("");
                        passwordP.setText("");
                        phoneP.setText("");
                        usernameP.setText("");

                        Toast.makeText(insPat.this, response, Toast.LENGTH_SHORT).show();
                    }
                },new Response.ErrorListener(){

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(insPat.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                }

                ){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> params = new HashMap<String, String>();
                      //  params.put("id_m",str_idm);
                        params.put("nome",str_nameP);
                        params.put("commenteur",str_comenteurP);
                        params.put("password",str_passwordP);
                        params.put("num",str_phoneP);
                        params.put("username",str_usernameP);
                        return params;


                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(insPat.this);
                requestQueue.add(request);


            }
    }

    public void RegisterPa(View view) {
    }
    }
*/
    }
}