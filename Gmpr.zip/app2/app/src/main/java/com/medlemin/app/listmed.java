package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class listmed extends AppCompatActivity {


    ListView listmedcin;
    RequestQueue requestQueue;
    String urli = "https://tirispress.net/pro/listpa.php";
    TextView textView;
    ArrayList<Task> listitems = new ArrayList<Task>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listmed);
        /*
        listmedcin = (ListView)findViewById(R.id.lism);



       requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urli,null,
                new Response.Listener<JSONObject>(){

            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("list");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject respons=jsonArray.getJSONObject(i);
                         // String name = respons.getString("nom");
                          String username =respons.getString("email");
                      //    int id =respons.getInt("id");
                        //  textView.append(name+"\n\n");
                           listitems.add(new Task(username));
                          listAllitem();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
           error.printStackTrace();
            }
        }
        );
        requestQueue.add(jsonObjectRequest);
    }
    public  void listAllitem(){
        listAdaptter lA=new listAdaptter(listitems);
        listmedcin.setAdapter(lA);
    }





   class listAdaptter extends BaseAdapter{
        ArrayList<Task> listA = new ArrayList<Task>();

       public listAdaptter(ArrayList<Task> listA) {
           this.listA = listA;
       }

       @Override
       public int getCount() {
           return listA.size();
       }

       @Override
       public Object getItem(int position) {
           return listA.get(position).nom;
       }

       @Override
       public long getItemId(int position) {
           return position;
       }

       @Override
       public View getView(int position, View convertView, ViewGroup parent) {
           LayoutInflater layoutInflater = getLayoutInflater();
           View view =layoutInflater.inflate(R.layout.llistpaitem,null);
           TextView nomeM = (TextView)view.findViewById(R.id.textView_name);
           nomeM.setText(listA.get(position).username);
           return view;
       }
   }
    }


*/
    }}


