package com.medlemin.app;

public class Task {

public String username;
public int num;
public String nom;

    public Task(String username, int num, String nom) {
        this.username = username;
        this.num = num;
        this.nom = nom;
    }

    public Task(String username) {
        this.username=username;
    }
}