package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        BottomNavigationView bottomNavpa = findViewById(R.id.nav_pat);
        bottomNavpa.setOnNavigationItemReselectedListener((BottomNavigationView.OnNavigationItemReselectedListener) navPlisner);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_containerpa,
                    new HomeFragment()).commit();
        }
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navPlisner =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.profile:
                            selectedFragment = new profile();
                            break;
                        case R.id.traitement:
                            selectedFragment = new traitement();
                            break;
                        case R.id.rendez:
                            selectedFragment = new rendez_vous();
                            break;
                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_containerpa,
                            selectedFragment).commit();

                    return true;
                }
            };

}
