package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListeVicule extends AppCompatActivity{
    /*

    private static final String TAG = ListeVicule.class.getSimpleName();
    List<Model> listItems;
    private RecyclerView recyclerView;
    String URL_SELECT =  Constants.URL+"projetSejad/AjoutV.php";//URL_SELECT
    ProgressBar progressBar;
    MyAdapter adapter;
    ArrayList<Model> arrayList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_vicule);

        recyclerView =(RecyclerView)findViewById(R.id.itemView);
        listItems = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        getDataFromServer();

    }

    private void getDataFromServer() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,URL_SELECT, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // progressBar.setVisibility(View.GONE);
                //  if (response != null) {
                Log.e(TAG, "onResponse: " + response);
                try { JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject data = jsonArray.getJSONObject(i);
                        arrayList.add(new Model(data.getString ("name"), data.getString("Marque"), data.getString("Module"), data.getString("carburant"), data.getString("TypeDeVille"), data.getString("TypeDeLocation"), data.getString("Prix"))); }
                    setAdapter();
                } catch (JSONException e) { e.printStackTrace(); }
                //}
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility( View.GONE);
                Log.e(TAG, "onErrorResponse: " + error); }
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void setAdapter() {
        Log.e(TAG, "setAdapter: " + arrayList.size());
        adapter = new Myadapter(arrayList);
        recyclerView.setAdapter(adapter);
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // MenuInflater inflater=getMenuInflater();
        getMenuInflater().inflate(R.menu.menu_list, menu);

        //SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        MenuItem searchMenuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchMenuItem.getActionView();

        //nuItem searchMenuItem = menu.findItem(R.id.action_search);

        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint("Search Car...");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(final String query) {
                // adapter.getFilter().filter(query);
                return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        //   searchMenuItem.getIcon().setVisible(false, false);
        return true;
    }

    public void action_agence(MenuItem item) {
        Intent intent = new Intent(ListeVicule.this, logine_agence.class);
        startActivity(intent);
    }

    public void  action_client(MenuItem item) {
        Intent intent = new Intent(ListeVicule.this, logine_from_client.class);
        startActivity(intent);
    }




    public void  action_setting(MenuItem item) {
        Intent intent = new Intent(ListeVicule.this, enregistrement_voitures.class);
        startActivity(intent);
    }

     */
}
