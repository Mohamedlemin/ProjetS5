package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class connection extends AppCompatActivity {
    private Button docteur;
    private Button patient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection);
        this.docteur =(Button)findViewById(R.id.doc);
        docteur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logD = new Intent(getApplicationContext(),loginDoct.class);
                startActivity(logD);
                finish();
            }
        });
        this.patient =(Button)findViewById(R.id.pati);
        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logP = new Intent(getApplicationContext(),loginPat.class);
                startActivity(logP);
                finish();
            }
        });
    }
}
