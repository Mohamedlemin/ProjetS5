package com.medlemin.s5gmpr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class loginPat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pat);
    }
}
