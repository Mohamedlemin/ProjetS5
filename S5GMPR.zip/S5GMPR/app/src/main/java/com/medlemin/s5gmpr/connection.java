package com.medlemin.s5gmpr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class connection extends AppCompatActivity {
    private Button docteur;
    private Button patient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection);
        this.docteur =(Button)findViewById(R.id.lancer);
        docteur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inscr = new Intent(getApplicationContext(),loginDoct.class);
                startActivity(inscr);
                finish();
            }
        });
        this.patient =(Button)findViewById(R.id.lancer);
        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inscr = new Intent(getApplicationContext(),loginPat.class);
                startActivity(inscr);
                finish();
            }
        });
    }
}
