package com.medlemin.s5gmpr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class loginDoct extends AppCompatActivity {

    private TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_doct);
        this.text =(TextView) findViewById(R.id.ins);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inscr = new Intent(getApplicationContext(),insDoct.class);
                startActivity(inscr);
                finish();
            }
        });
    }
}