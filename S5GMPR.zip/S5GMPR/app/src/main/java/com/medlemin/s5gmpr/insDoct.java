package com.medlemin.s5gmpr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class insDoct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins_doct);
    }
}
