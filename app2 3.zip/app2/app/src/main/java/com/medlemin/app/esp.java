package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class esp extends AppCompatActivity {
    private Button tr;
    private Button rnd;
    private Button urg;
    globalV gv;

    String nom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esp);



        gv=(globalV)getApplicationContext();


       // Log.d("key","patient nom ="+nom);
          nom=gv.getNomP();
        TextView text = (TextView) findViewById(R.id.nompaa);

       text.setText(nom);


     /*   this.tr =(Button)findViewById(R.id.trt);
        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tr = new Intent(getApplicationContext(),lisTesp.class);
                startActivity(tr);
                finish();
            }
        });
        this.rnd =(Button)findViewById(R.id.rndev);
        rnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent rndvv = new Intent(getApplicationContext(),listResp.class);
                startActivity(rndvv);
                finish();
            }
        });
        this.urg =(Button)findViewById(R.id.urgeence);
        urg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent uu = new Intent(getApplicationContext(),urgence.class);
                startActivity(uu);
                finish();
            }
        });*/




    }

    public void urg(View view) {
        Intent uu = new Intent(getApplicationContext(),urgence.class);
        startActivity(uu);
        finish();
    }


    public void Rn(View view) {
        Intent rndvv = new Intent(getApplicationContext(),listResp.class);
        startActivity(rndvv);
        finish();
    }

    public void trt(View view) {

        Intent rndvv = new Intent(getApplicationContext(),lisTesp.class);
        startActivity(rndvv);
        finish();
    }
}
