package com.medlemin.app;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FeedAdapter4 extends RecyclerView.Adapter<FeedAdapter4.FeedViewHolder4>{

    ArrayList<rndv_info> arrayListRn = new ArrayList<>();
    private Context mContext;


    public FeedAdapter4(Context context, ArrayList<rndv_info> arrayList) {

        this.arrayListRn = arrayList;
        mContext = context;
    }
    @Override
    public FeedAdapter4.FeedViewHolder4 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rendez, parent, false);
        return new FeedAdapter4.FeedViewHolder4(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedAdapter4.FeedViewHolder4 holder, int position) {
        final rndv_info datat = arrayListRn.get(position);
        String trt=datat.getDate();
        holder.rn.setText(trt);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(mContext, Rend_information.class);
              intent.putExtra("id_m", datat.getId_p());
                intent.putExtra("id_pa", datat.getId_p());
                intent.putExtra("date", datat.getDate());
                intent.putExtra("heure", datat.getHeure());
                intent.putExtra("note", datat.getNote());




                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayListRn.size();
    }

    class FeedViewHolder4 extends RecyclerView.ViewHolder {
        TextView rn;
        //   RelativeLayout parentLayout;

        FeedViewHolder4(@NonNull View itemView) {
            super(itemView);

            rn=(TextView)itemView.findViewById(R.id.rend_p);


        }
    }
}
