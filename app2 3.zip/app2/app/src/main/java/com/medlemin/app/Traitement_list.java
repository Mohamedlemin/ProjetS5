package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Traitement_list extends AppCompatActivity {
    globalV gv;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    FeedAdapter3 adapter;
    String n;
    final ArrayList<TraimentV> arrayList = new ArrayList<>();


    RadioButton rb_louees;
    RadioButton rb_disponibles;
    RadioButton rb_toutes;
    RequestQueue requestQueue;
    private FloatingActionButton bt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traitement_list);
        int idp = getIntent().getIntExtra("id_pa",0);
        Log.d("key","OnCreate valid!"+idp);
        String url = "https://tirispress.net/pro/listTraitemt.php?id_p="+idp;
        recyclerView = findViewById(R.id.ry_t);
        progressBar = findViewById(R.id.p_tr_pa);
        this.bt = (FloatingActionButton)findViewById(R.id.flo_tr_pa);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("alltr");
                            Log.d("key","try active traitement");
                           progressBar.setVisibility(View.GONE);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject dataT = jsonArray.getJSONObject(i);
                                arrayList.add(new TraimentV(
                                        dataT.getInt("id"),
                                        dataT.getInt("id_p"),
                                        dataT.getInt("id_m"),
                                        dataT.getString("nom_medicament"),
                                        dataT.getString("quentite"),
                                        dataT.getString("frequence"),
                                        dataT.getString("date_d"),
                                        dataT.getString("date_f")));

                                //  int id_P=data.getInt("id");
                                //  String commenteur=data.getString("commenteur");
                                //  int id_m=data.getInt("id_m");
                                   String num=dataT.getString("nom_medicament");
                                // String username=data.getString("username");
                                //gv.setP(nom);
                                //  gv.setId(id_P);
                                //  gv.setCommenteur(commenteur);
                                //  gv.setNum_p(num);
                                //gv.setId_m(id_m);
                                Log.d("key","voici le nom "+num);
                            }

                            setAdapter();


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active tr");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
//                Log.d("key","onErrorResponse active tr"+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getApplicationContext(),newTr.class);

                int idp = getIntent().getIntExtra("id_pa",0);
                int id_m= getIntent().getIntExtra("id_m",0);
                in.putExtra("id_pa",idp);
                in.putExtra("id_m",id_m);
                startActivity(in);
            }
        });
    }

    private void setAdapter () {
        adapter = new FeedAdapter3(this, arrayList);
        recyclerView.setAdapter(adapter);

    }



}

