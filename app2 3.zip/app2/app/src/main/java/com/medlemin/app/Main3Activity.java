package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        BottomNavigationView bottomNavpa = findViewById(R.id.patNav);
        bottomNavpa.setOnNavigationItemSelectedListener(navPl);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fconpa,
                    new profile()).commit();
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navPl =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fconpa,
                            selectedFragment).commit();

                    return true;
                }
            };

}
