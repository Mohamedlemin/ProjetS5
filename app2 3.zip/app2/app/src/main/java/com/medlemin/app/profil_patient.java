package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionsMenu;

public class profil_patient extends AppCompatActivity {
    TextView nomp,commenteur,numrr;
    String p_nom,cmt;
    String n;
    FloatingActionsMenu fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_patient);
        nomp=(TextView)findViewById(R.id.nom_pat);
        commenteur=(TextView)findViewById(R.id.commentair_pat);
        numrr=(TextView)findViewById(R.id.Numre_pa);
        String p_nom = getIntent().getStringExtra("nomP");
        String cmt = getIntent().getStringExtra("Commentaire");
        String n = getIntent().getStringExtra("numPat");


        nomp.setText(p_nom);
        commenteur.setText(cmt);

        numrr.setText(n);

        fab = findViewById(R.id.fabmenu);
        com.getbase.floatingactionbutton.FloatingActionButton fab1 = findViewById(R.id.fab_action1);
        com.getbase.floatingactionbutton.FloatingActionButton fab2 = findViewById(R.id.fab_action2);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logP = new Intent(getApplicationContext(),Traitement_list.class);
                int idp = getIntent().getIntExtra("id_pa",0);
                int id_m= getIntent().getIntExtra("id_m",0);
                logP.putExtra("id_pa",idp);
                logP.putExtra("id_m",id_m);
                startActivity(logP);
                fab.collapse();  // Close the fab menu
              //  Toast.makeText(profil_patient.this, "Button 1", Toast.LENGTH_SHORT).show();
            }
        });
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent logP = new Intent(getApplicationContext(),Rendez_Patient.class);
                int idp = getIntent().getIntExtra("id_pa",0);
                int id_m= getIntent().getIntExtra("id_m",0);
                logP.putExtra("id_pa",idp);
                logP.putExtra("id_m",id_m);
                startActivity(logP);

                fab.collapse(); //close the fab menu
              //  Toast.makeText(profil_patient.this, "Button 2", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void modifpa(View view) {
    }

    public void suprrim_P(View view) {
    }
}
