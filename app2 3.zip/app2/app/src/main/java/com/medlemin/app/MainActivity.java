package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*
        Bundle b=getIntent().getExtras();
        String user=b.getString("user");
*/
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        //I added this if statement to keep the selected fragment when rotating the device
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_contmed,
                    new HomeFragment()).commit();
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;


                    switch (item.getItemId()) {
                        case R.id.H:
                            selectedFragment = new HomeFragment();

                            break;
                        case R.id.A:
                           selectedFragment = new addpatients();
                            break;
                        case R.id.L:
                            selectedFragment = new List_ppaa();
                          //  Intent mySuperIntent = new Intent(MainActivity.this, Recycle_pat.class);
                          //  startActivity(mySuperIntent);
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_contmed,
                            selectedFragment).commit();

                    return true;
                }
            };



}