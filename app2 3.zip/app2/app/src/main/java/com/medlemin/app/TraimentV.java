package com.medlemin.app;

public class TraimentV {
    private  int idt;
    private int id_Pa;
    private int Id_med;
    private String nomMedic;
    private String Quntiter;
    private String frqc;

    public int getIdt() {
        return idt;
    }

    public void setIdt(int idt) {
        this.idt = idt;
    }

    private String datedb;
    private String datefin;

    public TraimentV(int idt,int id_Pa, int id_med, String nomMedic, String quntiter, String frqc, String datedb, String datefin) {
        this.idt=idt;
        this.id_Pa = id_Pa;
        Id_med = id_med;
        this.nomMedic = nomMedic;
        Quntiter = quntiter;
        this.frqc = frqc;
        this.datedb = datedb;
        this.datefin = datefin;
    }

    public TraimentV(String nomMedic) {
        this.nomMedic = nomMedic;
    }

    public int getId_Pa() {
        return id_Pa;
    }

    public void setId_Pa(int id_Pa) {
        this.id_Pa = id_Pa;
    }

    public int getId_med() {
        return Id_med;
    }

    public void setId_med(int id_med) {
        Id_med = id_med;
    }

    public String getNomMedic() {
        return nomMedic;
    }

    public void setNomMedic(String nomMedic) {
        this.nomMedic = nomMedic;
    }

    public String getQuntiter() {
        return Quntiter;
    }

    public void setQuntiter(String quntiter) {
        Quntiter = quntiter;
    }

    public String getFrqc() {
        return frqc;
    }

    public void setFrqc(String frqc) {
        this.frqc = frqc;
    }

    public String getDatedb() {
        return datedb;
    }

    public void setDatedb(String datedb) {
        this.datedb = datedb;
    }

    public String getDatefin() {
        return datefin;
    }

    public void setDatefin(String datefin) {
        this.datefin = datefin;
    }
}
