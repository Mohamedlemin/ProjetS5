package com.medlemin.app;

import android.app.Application;

public class globalV extends Application {
public String p;//nom patient
    public int id;//id patient
    private String nomP;//username patient
   public String nom;
  private String commenteur;//commenteur pa
    private int id_m; //id_m concter

    private String num_p;

    public String getNum_p() {
        return num_p;
    }

    public void setNum_p(String num_p) {
        this.num_p = num_p;
    }

    public int getId_m() {
        return id_m;
    }

    public void setId_m(int id_m) {
        this.id_m = id_m;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }

    public String getCommenteur() {
        return commenteur;
    }

    public void setCommenteur(String commenteur) {
        this.commenteur = commenteur;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    private String username;
    public String getNomP() {
        return nomP;
    }

    public void setNomP(String nomP) {
        this.nomP = nomP;
    }


    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

