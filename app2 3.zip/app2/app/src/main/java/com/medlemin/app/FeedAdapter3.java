package com.medlemin.app;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;

import org.json.JSONObject;

import java.util.ArrayList;
public class FeedAdapter3 extends RecyclerView.Adapter<FeedAdapter3.FeedViewHolder2>{

    ArrayList<TraimentV> arrayListT = new ArrayList<>();
    private Context mContext;

    public FeedAdapter3(Context context, ArrayList<TraimentV> arrayList) {

        this.arrayListT = arrayList;
        mContext = context;
    }
    @Override
    public FeedViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tra_pa_item, parent, false);
        return new FeedAdapter3.FeedViewHolder2(view);    }

    @Override
    public void onBindViewHolder(@NonNull FeedViewHolder2 holder, int position) {
        final TraimentV datat = arrayListT.get(position);
        String trt=datat.getNomMedic();
        holder.tr.setText(trt);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(mContext, tr_inf.class);
                intent.putExtra("nom_medicament", datat.getNomMedic());
                intent.putExtra("id_pa", datat.getId_Pa());
                intent.putExtra("Quntiter", datat.getQuntiter());
                intent.putExtra("id_m", datat.getId_med());
                intent.putExtra("frquance", datat.getFrqc());
                intent.putExtra("date_fin", datat.getDatefin());
                intent.putExtra("date_debut", datat.getDatedb());
                intent.putExtra("idT", datat.getIdt());


                mContext.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return arrayListT.size();
    }






    class FeedViewHolder2 extends RecyclerView.ViewHolder {
        TextView tr;
     //   RelativeLayout parentLayout;

        FeedViewHolder2(@NonNull View itemView) {
            super(itemView);

            tr=(TextView)itemView.findViewById(R.id.tr_item_patient);


        }
    }
}
