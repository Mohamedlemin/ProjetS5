package com.medlemin.app;

public class rndv_info {
    String Heure,date,note;
    int id_m,id_p;

    public String getHeure() {
        return Heure;
    }

    public void setHeure(String heure) {
        Heure = heure;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public int getId_m() {
        return id_m;
    }

    public void setId_m(int id_m) {
        this.id_m = id_m;
    }

    public int getId_p() {
        return id_p;
    }

    public void setId_p(int id_p) {
        this.id_p = id_p;
    }

    public rndv_info(String heure, String date, String note, int id_m, int id_p) {
        Heure = heure;
        this.date = date;
        this.note = note;
        this.id_m = id_m;
        this.id_p = id_p;
    }
}
