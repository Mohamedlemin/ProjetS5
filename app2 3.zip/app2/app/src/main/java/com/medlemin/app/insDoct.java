package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.cardview.widget.CardView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.Map;
import java.util.HashMap;


public class insDoct extends AppCompatActivity {
    private TextView text;
    ImageView top_curve;
    EditText name, email, password,phone;
    TextView name_text, email_text, password_text, login_title,phone_txt;
    ImageView logo;
    LinearLayout already_have_account_layout;
    CardView register_card;
    String str_name,str_email,str_password,str_phone;
    ProgressBar pb;
    RequestQueue queue;

    Button btn_send;
    ProgressBar pp;
    String url ="https://tirispress.net/pro/insert.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins_doct);
        top_curve = findViewById(R.id.top_curve);
        name = findViewById(R.id.name);
        phone =findViewById(R.id.numr);
        phone_txt=findViewById(R.id.num);
        name_text = findViewById(R.id.name_text);
        email = findViewById(R.id.email);
        email_text = findViewById(R.id.email_text);
        password = findViewById(R.id.password);
        password_text = findViewById(R.id.password_text);
        logo = findViewById(R.id.logom);
        login_title = findViewById(R.id.registration_title);
        already_have_account_layout = findViewById(R.id.already_have_account_text);
        register_card = findViewById(R.id.register_card);



        //animation

        Animation top_curve_anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.top_down);
        top_curve.startAnimation(top_curve_anim);

        Animation editText_anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.edittext_anim);
        name.startAnimation(editText_anim);
        email.startAnimation(editText_anim);
        password.startAnimation(editText_anim);
        phone.startAnimation(editText_anim);

        Animation field_name_anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.field_name_anim);
        name_text.startAnimation(field_name_anim);
        email_text.startAnimation(field_name_anim);
        phone_txt.startAnimation(field_name_anim);

        password_text.startAnimation(field_name_anim);
        logo.startAnimation(field_name_anim);
        login_title.startAnimation(field_name_anim);

        Animation center_reveal_anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.center_reveal_anim);
        register_card.startAnimation(center_reveal_anim);

        Animation new_user_anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.down_top);
        already_have_account_layout.startAnimation(new_user_anim);

        //inistalisation
        btn_send = (Button) findViewById(R.id.btn_send);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        phone = (EditText) findViewById(R.id.numr);








        this.text =(TextView) findViewById(R.id.loginbtn);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inscr = new Intent(getApplicationContext(),loginDoct.class);
                startActivity(inscr);
                finish();
            }
        });

    }


    public void Enregister(View view) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");
        Log.d("key","enrgstrer valid!");

        if(name.getText().toString().equals("")){
            Toast.makeText(this, "Enter Username", Toast.LENGTH_SHORT).show();
        }
        else if(email.getText().toString().equals("")){
            Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show();
        }
        else if(password.getText().toString().equals("")){
            Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show();
        }
        else if(phone.getText().toString().equals("")){
            Toast.makeText(this, "Enter le num du telephone", Toast.LENGTH_SHORT).show();
        }
        else{

            progressDialog.show();
            str_name = name.getText().toString().trim();
            str_email = email.getText().toString().trim();
            str_password = password.getText().toString().trim();
            str_phone = phone.getText().toString().trim();
            Log.d("key","les donner!"+str_email+" "+str_name);
            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    name.setText("");
                    email.setText("");
                    password.setText("");
                    phone.setText("");
                    Toast.makeText(insDoct.this, response, Toast.LENGTH_SHORT).show();
                    Log.d("key","onresponse valid!");
                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Log.d("key","OnError valid!"+error.getCause().getMessage());
                    Toast.makeText(insDoct.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();

                    params.put("pseudo",str_name);
                    params.put("email1",str_email);
                    params.put("password1",str_password);
                    params.put("num",str_phone);
                    return params;



                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(insDoct.this);
            requestQueue.add(request);


        }
    }
}