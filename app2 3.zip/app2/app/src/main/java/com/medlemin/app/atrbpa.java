package com.medlemin.app;

public class atrbpa {
    private int id;
    private String nom;
    private String username;
    private String commenteur;

    public atrbpa(String nom, String username, String commenteur) {
        this.nom = nom;
        this.username = username;
        this.commenteur = commenteur;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCommenteur() {
        return commenteur;
    }

    public void setCommenteur(String commenteur) {
        this.commenteur = commenteur;
    }
}
