package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Rendez_Patient extends AppCompatActivity {
    globalV gv;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    FeedAdapter4 adapter;
    String n;
    final ArrayList<rndv_info> arrayList = new ArrayList<>();


    RadioButton rb_louees;
    RadioButton rb_disponibles;
    RadioButton rb_toutes;
    RequestQueue requestQueue;
    private FloatingActionButton bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rendez__patient);
        int idp = getIntent().getIntExtra("id_pa",0);
        Log.d("key","OnCreate valid!"+idp);
        String url = "https://tirispress.net/pro/listRendv.php?id_p="+idp;
        recyclerView = findViewById(R.id.recyclerView_Rendv);
        progressBar = findViewById(R.id.progressBar_rendv);

        this.bt = (FloatingActionButton)findViewById(R.id.floatingActionButton_rnd);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("alltr");
                            Log.d("key","try active rndv");
                            progressBar.setVisibility(View.GONE);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject dataT = jsonArray.getJSONObject(i);
                                arrayList.add(new rndv_info(
                                        dataT.getString("heure"),
                                        dataT.getString("date"),
                                        dataT.getString("note"),
                                        dataT.getInt("id_m"),
                                        dataT.getInt("id_p")));

                                //  int id_P=data.getInt("id");
                                //  String commenteur=data.getString("commenteur");
                                //  int id_m=data.getInt("id_m");
                             //   String num=dataT.getString("nom_medicament");
                                // String username=data.getString("username");
                                //gv.setP(nom);
                                //  gv.setId(id_P);
                                //  gv.setCommenteur(commenteur);
                                //  gv.setNum_p(num);
                                //gv.setId_m(id_m);
                               // Log.d("key","voici le date "+num);
                            }

                            setAdapter();


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active ");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
//                Log.d("key","onErrorResponse active tr"+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getApplicationContext(),newrnd.class);

                int idp = getIntent().getIntExtra("id_pa",0);
                int id_m= getIntent().getIntExtra("id_m",0);
                in.putExtra("id_pa",idp);
                in.putExtra("id_m",id_m);
                startActivity(in);
            }
        });
    }

    private void setAdapter () {
        adapter = new FeedAdapter4(this, arrayList);
        recyclerView.setAdapter(adapter);

    }



}

