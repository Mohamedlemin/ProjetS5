package com.medlemin.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FeedAdapter2 extends RecyclerView.Adapter<FeedAdapter2.FeedViewHolder> {
    ArrayList<pat_info> arrayList = new ArrayList<>();



   // private static final String TAG = "FeedAdapter2";
    private Context mContext;



    public FeedAdapter2(Context context, ArrayList<pat_info> arrayList) {

        this.arrayList = arrayList;
        mContext = context;
    }

    @NonNull
    public FeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.llistpaitem, parent, false);
        return new FeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FeedViewHolder holder, int position) {
         final pat_info dataP = arrayList.get(position);
        holder.nomP.setText(dataP.getNomp());


        //Glide.with(mContext).load("http://10.0.2.2/login/image/" + data.getPhoto ())
                //.placeholder(R.drawable.imagev)
                // .error(R.drawable.imagev)
             //   .into(holder.photo);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent;
                intent = new Intent(mContext, profil_patient.class);
               intent.putExtra("nomP", dataP.getNomp());
                intent.putExtra("id_pa", dataP.getIdp());
                intent.putExtra("Commentaire", dataP.getCom());
                intent.putExtra("id_m", dataP.getId_m());
                intent.putExtra("numPat", dataP.getNum());


                mContext.startActivity(intent);
            }
        });







    }

    @Override
    public int getItemCount() {
        return arrayList.size();

    }

    class FeedViewHolder extends RecyclerView.ViewHolder {
        TextView nomP;
        RelativeLayout parentLayout;

        FeedViewHolder(@NonNull View itemView) {
            super(itemView);

            nomP = (TextView) itemView.findViewById(R.id.pan);





        }


    }

}