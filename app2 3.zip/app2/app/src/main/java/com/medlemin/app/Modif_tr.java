package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Modif_tr extends AppCompatActivity {

    EditText nommedi, quantite, dated,datefin,frequance;
    int idm,id_tr;
    final    int  idp = getIntent().getIntExtra("id_pa",0);

    String tr_mod_nom,tr_modif_quanti,tr_modif_frqnc,tr_modif_datdb,tr_modi_datefin;
    String str_nommd,str_qun,str_frq,str_use,S_datedb,S_date_fin,sr_idp,sr_idm;
    //  gv = (globalV) getActivity().getApplication();
    String url ="https://tirispress.net/pro/modif_tr.php";
    ProgressBar pb;
    globalV gv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modif_tr);
        nommedi = findViewById(R.id.modif_tr_nom);
        quantite =findViewById(R.id.modif_tr_quint);
        dated=findViewById(R.id.modif_tr_dateDb);
        datefin = findViewById(R.id.modif_tr_date_fin);
        frequance = findViewById(R.id.modif_tr_frq);
        idm= getIntent().getIntExtra("id_m",0);
        // idp=findViewById(R.id.idpaaa);
        // idm=findViewById(R.id.idmmm);
        tr_mod_nom = getIntent().getStringExtra("nom_medicament");
        tr_modif_quanti = getIntent().getStringExtra("Quntiter");
        tr_modif_frqnc = getIntent().getStringExtra("frquance");
        tr_modif_datdb = getIntent().getStringExtra("date_debut");
        tr_modi_datefin = getIntent().getStringExtra("date_fin");
        id_tr = getIntent().getIntExtra("idT",0);
        nommedi.setText(tr_mod_nom);
        quantite.setText(tr_modif_quanti);
        dated.setText(tr_modif_datdb);
        datefin.setText(tr_modi_datefin);
        frequance.setText(tr_modif_frqnc);

    }

    public void modif_trt(View view) {









            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please Wait..");
            Log.d("key","modification valid!"+id_tr+" "+tr_mod_nom+" "+tr_modif_quanti+" "+tr_modif_datdb+" "+tr_modi_datefin+" "+tr_modif_frqnc);

            if(nommedi.getText().toString().equals("")){
                Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
            }
            else if(quantite.getText().toString().equals("")){
                Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
            }
            else if(dated.getText().toString().equals("")){
                Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
            }
            else if(datefin.getText().toString().equals("")){
                Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
            }
            else{

                progressDialog.show();
                str_nommd = nommedi.getText().toString().trim();
                str_qun = quantite.getText().toString().trim();
                str_frq = frequance.getText().toString().trim();
                // str_use = use.getText().toString().trim();
                S_datedb = dated.getText().toString().trim();
                S_date_fin = datefin.getText().toString().trim();
                // idp=gv.getId();
                // idm=gv.getId_m();

              //  Log.d("key","les donner!"+idm+" "+idp);
                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        Log.d("key","Onreponse valid!");

                        if (response.equalsIgnoreCase("ok")) {

                            progressDialog.dismiss();

                            Log.d("key"," succuse!");

                            Intent logP = new Intent(Modif_tr.this,Traitement_list.class);
                            startActivity(logP);
                            logP.putExtra("id_pa", idp);

                            Toast.makeText(Modif_tr.this, "success", Toast.LENGTH_SHORT).show();

                        } else {
                            progressDialog.dismiss();
                            Log.d("key"," field!");

                            Toast.makeText(Modif_tr.this, "Erreur de modification", Toast.LENGTH_SHORT).show();

                        }
                    }
                },new Response.ErrorListener(){

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Log.d("key","OnError valid!"+error.getCause().getMessage());
                        Toast.makeText(getApplicationContext(), error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                }

                ){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> params = new HashMap<String, String>();

                        params.put("nmdc",str_nommd);
                        params.put("qunt",str_qun);
                        params.put("frq",str_frq);
                        //   params.put("use",str_use);
                        params.put("datd",S_datedb);
                        params.put("datf",S_date_fin);
                        params.put("idm", String.valueOf(idm));
                        params.put("idp", String.valueOf(idp));
                        params.put("id", String.valueOf(id_tr));


                        return params;



                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(request);


            }
        }
    }



