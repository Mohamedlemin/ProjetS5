package com.medlemin.app;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class profile extends Fragment {


    public profile() {
        // Required empty public constructor
    }

TextView nomp,commenteur,numrr;
String p,cmt;
String n;
    globalV gvp;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v= inflater.inflate(R.layout.fragment_profile, container, false);
      //  gvp=(globalV)getActivity().getApplicationContext();
        nomp=(TextView)v.findViewById(R.id.nom_pat);
        commenteur=(TextView)v.findViewById(R.id.commentair_pat);
        numrr=(TextView)v.findViewById(R.id.Numre_pa);

        p=((globalV)getActivity().getApplication()).getP();
        cmt=((globalV)getActivity().getApplication()).getCommenteur();
        n=((globalV)getActivity().getApplication()).getNum_p();
                //nom= ((globalV)getActivity().getApplication()).getNom();
       nomp.setText(p);
       commenteur.setText(cmt);
       numrr.setText(n);
        return v;
    }

}
