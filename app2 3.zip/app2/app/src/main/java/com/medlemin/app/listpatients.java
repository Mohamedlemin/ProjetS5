package com.medlemin.app;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class listpatients extends Fragment {


    public listpatients() {
        // Required empty public constructor
    }
    globalV gv;
    String nomM;

    ListView listmedcin;
    RequestQueue requestQueue;



    TextView textView;
    ArrayList<Task> listitems = new ArrayList<Task>();
   // globalVp nomP;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        nomM= ((globalV)getActivity().getApplication()).getNom();

        String urli = "https://tirispress.net/pro/listpa.php?nom="+nomM;
        gv=(globalV)getActivity().getApplicationContext();


        final View v =inflater.inflate(R.layout.fragment_listpatients, container, false);
       final ListView  listmedcin = (ListView) v.findViewById(R.id.list);






        requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urli,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("allpa");

                            Log.d("key","try active");


                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject respons= jsonArray.getJSONObject(i);
                                String nom =respons.getString("nom");
                                 int id_P=respons.getInt("id");
                                 String commenteur=respons.getString("commenteur");
                                 int id_m=respons.getInt("id_m");
                                 String num=respons.getString("num");
                                 String username=respons.getString("username");
                                 gv.setP(nom);
                                 gv.setId(id_P);
                                 gv.setCommenteur(commenteur);
                                 gv.setNum_p(num);
                                 gv.setId_m(id_m);
                                Log.d("key","voici le nom "+gv.getCommenteur());



                              listitems.add(new Task(nom));
                                listAdaptter lA=new listAdaptter(listitems);
                                listmedcin.setAdapter(lA);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("key","onErrorResponse active"+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);


        return v;
    }
/*
   public  void listAllitem(){

        listAdaptter lA=new listAdaptter(listitems);
        listmedcin.setAdapter(lA);
    }
*/





    class listAdaptter extends BaseAdapter {

        ArrayList<Task> listA = new ArrayList<Task>();

        public listAdaptter(ArrayList<Task> listA) {
            this.listA = listA;
        }

        @Override
        public int getCount() {
            return listA.size();
        }

        @Override
        public Object getItem(int position) {
            return listA.get(position).nom;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int i, View convertView, ViewGroup parent) {

            LayoutInflater layoutInflater = getLayoutInflater();
            View view =layoutInflater.inflate(R.layout.llistpaitem,null);
            TextView nomeM = (TextView)view.findViewById(R.id.pan);
            nomeM.setText(listA.get(i).nom);
         /*   nomeM.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent profile =new Intent(getActivity(),Main3Activity.class);
                  //  profile.putExtra("nomPa",listitems.get(i).nom);
                    startActivity(profile);
                }
            });*/
            return view;
        }
    }
}
