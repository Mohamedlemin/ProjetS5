package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import androidx.appcompat.widget.Toolbar;
import java.util.HashMap;
import java.util.Map;

public class loginPat extends AppCompatActivity {
    Button btntst;
    TextView patnam;
    EditText logp,pass;
    String S_name,S_password;
    globalV gv;
    Toolbar toolbar;
    String url ="https://tirispress.net/pro/logpat.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pat);
        gv=(globalV)getApplicationContext();
        logp = (EditText) findViewById(R.id.p_n);
        toolbar=findViewById(R.id.login_pat_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Login");
        if(getSupportActionBar() != null) {
            Log.d("key","nor null");
            getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
       // getSupportActionBar().setDisplayShowCustomEnabled(true);
        pass = (EditText) findViewById(R.id.p_pas);
        this.btntst = (Button) findViewById(R.id.login_buttonPa);
       // name = logp.getText().toString().trim();
       // password=pass.getText().toString().trim();

        btntst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final ProgressDialog progressDialog = new ProgressDialog(loginPat.this);
                progressDialog.setMessage("Please Wait..");


                if(logp.getText().toString().equals("")){
                    Toast.makeText(loginPat.this, "Taper votre nom", Toast.LENGTH_SHORT).show();
                }
                else if(pass.getText().toString().equals("")){
                    Toast.makeText(loginPat.this, "Taper votre mot de passe", Toast.LENGTH_SHORT).show();
                }
                else {

                    progressDialog.show();

                    S_name = logp.getText().toString().trim();
                   S_password = pass.getText().toString().trim();
                    //   nomDoc="str_email";


                    StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            if (response.equalsIgnoreCase("ok")){

                                progressDialog.dismiss();

                                logp.setText("");
                                pass.setText("");
                                gv.setNomP(S_name);
                                startActivity(new Intent(loginPat.this, esp.class));

                               // Log.d("key","patient nom ="+gnomp.getNomp());

                                Toast.makeText(loginPat.this, response, Toast.LENGTH_SHORT).show();
                            }else {
                                progressDialog.dismiss();

                                logp.setText("");
                                pass.setText("");
                                Toast.makeText(loginPat.this, "verifier votre nom ou votre mot de passe", Toast.LENGTH_SHORT).show();


                            }
                        }

                    },new Response.ErrorListener(){

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                            Toast.makeText(loginPat.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    ){
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String,String> params = new HashMap<String, String>();


                            params.put("name",S_name);
                            params.put("password",S_password);

                            return params;


                        }
                    };

                    RequestQueue requestQueue = Volley.newRequestQueue(loginPat.this);
                    requestQueue.add(request);

                }



              //  Intent lism = new Intent(getApplicationContext(), esp.class);
              //  b.putString("user",logp.getText().toString());
              //  lism.putExtras(b);
              //  startActivity(lism);
               // finish();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.patient_nav,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch ( item.getItemId()){
            case R.id.back:
                Intent in =new Intent(getApplicationContext(),connection.class);
                startActivity(in);
                break;
        }


        return super.onOptionsItemSelected(item);
    }


}
