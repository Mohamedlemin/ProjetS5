package com.medlemin.app;

public class pat_info {
    int idp;
    String nomp;
    int id_m;
    String num;
    String com;

    public pat_info(int idp, String nomp, int id_m, String num, String com) {
        this.idp = idp;
        this.nomp = nomp;
        this.id_m = id_m;
        this.num = num;
        this.com = com;
    }

    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public String getNomp() {
        return nomp;
    }

    public void setNomp(String nomp) {
        this.nomp = nomp;
    }

    public int getId_m() {
        return id_m;
    }

    public void setId_m(int id_m) {
        this.id_m = id_m;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getCom() {
        return com;
    }

    public void setCom(String com) {
        this.com = com;
    }
}
