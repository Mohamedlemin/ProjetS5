package com.medlemin.app;

public class Trt_class {
    private int id_patient;
    private String nom_medicament;

    public Trt_class(int id_patient, String nom_medicament) {
        this.id_patient = id_patient;
        this.nom_medicament = nom_medicament;
    }

    public int getId_patient() {
        return id_patient;
    }

    public void setId_patient(int id_patient) {
        this.id_patient = id_patient;
    }

    public String getNom_medicament() {
        return nom_medicament;
    }

    public void setNom_medicament(String nom_medicament) {
        this.nom_medicament = nom_medicament;
    }
}
