package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class loginDoct extends AppCompatActivity {
    private TextView text;
    private Button login;
    ImageView top_curve;
    EditText email, password;
    TextView email_text, password_text, login_title;
    ImageView logo;
    LinearLayout new_user_layout;
    CardView login_card;
    String str_email,str_password;
    String url ="https://tirispress.net/pro/logDoct.php";
    //public static String nomDoc="";

    globalV gv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_doct);
        top_curve = findViewById(R.id.top_curve);
        email = (EditText) findViewById(R.id.email);
        email_text = findViewById(R.id.email_text);
        password = (EditText) findViewById(R.id.password);
        password_text = findViewById(R.id.password_text);
        logo = findViewById(R.id.logo);
        login_title = findViewById(R.id.login_text);
        new_user_layout = findViewById(R.id.new_user_text);
        login_card = findViewById(R.id.login_card);

        Animation top_curve_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.top_down);
        top_curve.startAnimation(top_curve_anim);

        Animation editText_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.edittext_anim);
        email.startAnimation(editText_anim);
        password.startAnimation(editText_anim);

        Animation field_name_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.field_name_anim);
        email_text.startAnimation(field_name_anim);
        password_text.startAnimation(field_name_anim);
        logo.startAnimation(field_name_anim);
        login_title.startAnimation(field_name_anim);

        Animation center_reveal_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.center_reveal_anim);
        login_card.startAnimation(center_reveal_anim);

        Animation new_user_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.down_top);
        new_user_layout.startAnimation(new_user_anim);

        gv=(globalV)getApplicationContext();

        this.text = (TextView) findViewById(R.id.ins);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inscr = new Intent(getApplicationContext(), insDoct.class);

                startActivity(inscr);
                finish();
            }
        });


    }

    public void login(View view) {
        /*
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");
        if (email.getText().toString().equals("")) {
            Toast.makeText(loginDoct.this, "Taper votre email", Toast.LENGTH_SHORT).show();
        } else if (password.getText().toString().equals("")) {
            Toast.makeText(loginDoct.this, "Taper votre mot de passe", Toast.LENGTH_SHORT).show();
        } else {
            progressDialog.show();

            String emailD = email.getText().toString().trim();
            String passD = password.getText().toString().trim();
            Response.Listener<String> responseLisner = new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonReponse = new JSONObject(response);
                        boolean success = jsonReponse.getBoolean("success");

                        if (success) {
                            progressDialog.dismiss();
                            password.setText("");
                            email.setText("");
                            Toast.makeText(loginDoct.this, response, Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(loginDoct.this, EspaceDoc.class));
                        }else {
                            Toast.makeText(loginDoct.this, "verifier vos donnees", Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            };*/


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");


        if(email.getText().toString().equals("")){
            Toast.makeText(loginDoct.this, "Taper votre email", Toast.LENGTH_SHORT).show();
        }
        else if(password.getText().toString().equals("")){
            Toast.makeText(loginDoct.this, "Taper votre mot de passe", Toast.LENGTH_SHORT).show();
        }


        else{

            progressDialog.show();

            str_email = email.getText().toString().trim();
            str_password = password.getText().toString().trim();
         //   nomDoc="str_email";


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (response.equalsIgnoreCase("ok")){

                        progressDialog.dismiss();

                        email.setText("");
                        password.setText("");

                        startActivity(new Intent(loginDoct.this, HomePage.class));
                        gv.setNom(str_email);

                        Toast.makeText(loginDoct.this, "Bienvenue", Toast.LENGTH_SHORT).show();
                    }else {
                        progressDialog.dismiss();

                        email.setText("");
                        password.setText("");
                        Toast.makeText(loginDoct.this, "verifier votre nom ou votre mot de passe", Toast.LENGTH_SHORT).show();


                    }
                    }

            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                   Toast.makeText(loginDoct.this,"Verifier votre connexion internet", Toast.LENGTH_SHORT).show();
//                    Log.d("key","onErrorResponse active"+error.getCause().getMessage());
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();


                    params.put("email",str_email);
                    params.put("password",str_password);

                    return params;


                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(loginDoct.this);
            requestQueue.add(request);


        }
    }
}
