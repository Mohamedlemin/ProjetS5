package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import androidx.appcompat.widget.Toolbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Recycle_pat extends AppCompatActivity {

    globalV gv;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    FeedAdapter2 adapter;
    String n;
    Toolbar toolbar;

    final ArrayList<pat_info> arrayList = new ArrayList<>();


    RadioButton rb_louees;
    RadioButton rb_disponibles;
    RadioButton rb_toutes;
    RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_pat);
        toolbar=findViewById(R.id.toolbar_lisp);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);

        gv=(globalV)getApplicationContext();
        n=gv.getNom();
        String urli = "https://tirispress.net/pro/listpa.php?nom="+n;
            recyclerView = findViewById(R.id.Recy_pat);
            progressBar = findViewById(R.id.prgrs);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));


        requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urli,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("allpa");
                                Log.d("key","try active");
                            progressBar.setVisibility(View.GONE);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject data = jsonArray.getJSONObject(i);
                                    arrayList.add(new pat_info(
                                            data.getInt("id"),
                                            data.getString("nom"),
                                            data.getInt("id_m"),
                                            data.getString("num"),
                                            data.getString("commenteur")));

                                    String nom =data.getString("nom");
                                  //  int id_P=data.getInt("id");
                                  //  String commenteur=data.getString("commenteur");
                                  //  int id_m=data.getInt("id_m");
                                 //   String num=data.getString("num");
                                   // String username=data.getString("username");
                                    gv.setP(nom);
                                  //  gv.setId(id_P);
                                  //  gv.setCommenteur(commenteur);
                                  //  gv.setNum_p(num);
                                    //gv.setId_m(id_m);
                                    Log.d("key","voici le nom ");
                                }
                                setAdapter();


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("key","onErrorResponse active"+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);

    }

    private void setAdapter () {
        adapter = new FeedAdapter2(this, arrayList);
        recyclerView.setAdapter(adapter);
    }



}

