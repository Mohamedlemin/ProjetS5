package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class newrnd extends AppCompatActivity {
    EditText Heure, date, note;
    private    String str_Heure,str_date,str_note;
    int id_p,id_m;
    String url ="https://tirispress.net/pro/addRndv.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newrnd);
        Heure = (EditText) findViewById(R.id.Heure_rnd);
        date = (EditText) findViewById(R.id.date_rnd);
        note = (EditText) findViewById(R.id.note);
        id_p = getIntent().getIntExtra("id_pa",0);
        id_m= getIntent().getIntExtra("id_m",0);
        Log.d("key","les donnee!"+id_p+" "+id_m);

    }
    public void newrndvouos(View view) {



        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");


        if(Heure.getText().toString().equals("")){
            Toast.makeText(this, "inserer l'heure", Toast.LENGTH_SHORT).show();
        }
        else if(date.getText().toString().equals("")){
            Toast.makeText(this, "Enter le date slvp", Toast.LENGTH_SHORT).show();
        }
        else if(note.getText().toString().equals("")){
            Toast.makeText(this, "commentaire slvp", Toast.LENGTH_SHORT).show();
        }


        else{

            progressDialog.show();
            str_Heure = Heure.getText().toString().trim();
            str_date = date.getText().toString().trim();
            str_note = note.getText().toString().trim();



            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    Heure.setText("");
                    date.setText("");
                    note.setText("");
                    Log.d("key","onresponse valid!");
                    Intent in =new Intent(getApplicationContext(),Rendez_Patient.class);
                    in.putExtra("id_pa",id_p);
                    startActivity(in);
                    Toast.makeText(getApplicationContext(), "registre successfuly", Toast.LENGTH_SHORT).show();
                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Log.d("key","OnError valid!"+error.getCause().getMessage());
                    Toast.makeText(newrnd.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
//                    Toast.makeText(getApplicationContext(), error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("id_m", String.valueOf(id_m));
                    params.put("id_p", String.valueOf(id_p));
                    params.put("heure",str_Heure);
                    params.put("date",str_date);
                    params.put("note",str_note);
                    return params;


                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(newrnd.this);
            requestQueue.add(request);


        }



    }
}
