package com.medlemin.app;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class traitement extends Fragment {


    public traitement() {
        // Required empty public constructor
    }
    ArrayList<TraimentV> listtr = new ArrayList<TraimentV>();
   // ListView listtr;
    globalV gv;
    RequestQueue requestQueue;



    private FloatingActionButton bt;

    RecyclerView recyclerView;
    ProgressBar progressBar;

    FeedAdapter2 adapter;

    ArrayList<TraimentV> arrayList = new ArrayList<>();




    RadioButton rb_louees;
    RadioButton rb_disponibles;
    RadioButton rb_toutes;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_traitement, container, false);
       /* final ListView  listTrtm = (ListView) v.findViewById(R.id.lt);
       // recyclerView = v.findViewById(R.id.list_rv2);
       // progressBar = v.findViewById(R.id.progress_circular);
        //recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        gv = (globalV) getActivity().getApplicationContext();
        int idp = ((globalV) getActivity().getApplication()).getId();
        String url = "https://tirispress.net/pro/listTraitemt.php?id_p="+idp;
        listTrtm.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                startActivity(new Intent(getContext(), tr_inf.class));
                // nomP.setNomp(listmedcin.getItemAtPosition(i).toString());
            }
        });
     //   getDataFromServer();
        this.bt = (FloatingActionButton) v.findViewById(R.id.flt);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(), newTr.class);
                startActivity(in);
            }
        });



        requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>(){


                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("key","onresponse valid!");
                        try {
                            JSONArray jsonArray = response.getJSONArray("alltr");

                            Log.d("key","try active");


                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject respons= jsonArray.getJSONObject(i);



                                String nomtr=respons.getString("nom_medicament");


                                listtr.add(new TraimentV(nomtr));
                                listrAd lA=new listrAd(listtr);
                                listTrtm.setAdapter(lA);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("key","catch active");
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.e("key","onErrorResponse active   "+error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);









*/
        return v;
    }


    /*class listrAd extends BaseAdapter {

        ArrayList<TraimentV> listT = new ArrayList<TraimentV>();

        public listrAd(ArrayList<TraimentV> listT) {
            this.listT = listT;
        }

        @Override
        public int getCount() {
            return listT.size();
        }

        @Override
        public Object getItem(int position) {
            return listT.get(position).getNomMedic();
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int i, View convertView, ViewGroup parent) {

            LayoutInflater layoutInflater = getLayoutInflater();
            View view =layoutInflater.inflate(R.layout.traitementitem,null);
        //    TextView nomeM = (TextView)view.findViewById(R.id.trami);
            //nomeM.setText(listT.get(i).getNomMedic());
         /*   nomeM.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent profile =new Intent(getActivity(),Main3Activity.class);
                  //  profile.putExtra("nomPa",listitems.get(i).nom);
                    startActivity(profile);
                }
            });

        }
    }

/*
    private void getDataFromServer() {
        /*
        requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressBar.setVisibility(View.GONE);
                        if (response != null) {
                            try {
                                JSONArray jsonArray = response.getJSONArray("alltr");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject data= jsonArray.getJSONObject(i);
                                    arrayList.add(new TraimentV(
                                            // data.getString("")
                                            data.getInt("idp"),
                                            data.getInt("idm"),
                                            data.getString("nmdc"),
                                            data.getString("qunt"),
                                            data.getString("frq"),
                                            data.getString("datd"),
                                            data.getString("datf")
                                    ));
                                }
                                adapter = new FeedAdapter2(getContext(), arrayList);
                                recyclerView.setAdapter(adapter);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("key", "onErrorResponse active" + error.getCause().getMessage());
            }
        }
        );
        requestQueue.add(jsonObjectRequest);

     //  requestQueue = Volley.newRequestQueue(getActivity());
     /*
       */

      /*  StringRequest stringRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressBar.setVisibility(View.GONE);
                        if (response != null) {
                            Log.d("key", "onResponse: " + response);
                            try {
                                JSONArray jsonArray = new JSONArray(response);

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject data = jsonArray.getJSONObject(i);
                                    arrayList.add(new TraimentV (
                                           // data.getString("")
                                            data.getInt ( "idp" ),
                                            data.getInt ("idm"),
                                            data.getString("nmdc"),
                                            data.getString ( "qunt" ),
                                            data.getString ( "frq" ),
                                            data.getString("datd"),
                                            data.getString("datf")
                                            ));
                                }
                                setAdapter();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility( View.GONE);
                        Log.d("key", "onErrorResponse: " + error.getCause().getMessage());
                    }
                });
        Volley.newRequestQueue(getContext()).add(stringRequest);

    }*/


      /*  private void setAdapter () {
            // Log.e(TAG, "setAdapter: " + arrayList.size());
            adapter = new FeedAdapter2(getContext(), arrayList);
            recyclerView.setAdapter(adapter);
        }*/

}



