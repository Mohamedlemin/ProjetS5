package com.medlemin.app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class tr_inf extends AppCompatActivity {
    TextView nomMedic, Quntiter, frquance, datedebit, date_fin;
    String nomM, quntiter, frqunce, detdb, dtfin;
    int id,idp;
//    int  idp = getIntent().getIntExtra("id_pa",0);

    ProgressBar progressBar;
    String deleteUrl = "https://tirispress.net/pro/SupprimerT.php";
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tr_inf);
        nomMedic = (TextView) findViewById(R.id.Nom_tr);
        Quntiter = (TextView) findViewById(R.id.Qun_tr);
        frquance = (TextView) findViewById(R.id.frq_tr);
        datedebit = (TextView) findViewById(R.id.datdb_tr);
        date_fin = (TextView) findViewById(R.id.date_fin_tr);
        progressBar = findViewById(R.id.progressBar_trt);

        nomM = getIntent().getStringExtra("nom_medicament");
        quntiter = getIntent().getStringExtra("Quntiter");
        frqunce = getIntent().getStringExtra("frquance");
        detdb = getIntent().getStringExtra("date_debut");
        dtfin = getIntent().getStringExtra("date_fin");

        idp = getIntent().getIntExtra("id_pa",0);
        id = getIntent().getIntExtra("idT",0);
        nomMedic.setText(nomM);
        Quntiter.setText(quntiter);
        frquance.setText(frqunce);
        datedebit.setText(detdb);
        date_fin.setText(dtfin);
    }

    public void modif(View view) {

        Intent intent = new Intent(tr_inf.this, Modif_tr.class);
        intent.putExtra("nom_medicament",nomM );
        intent.putExtra("Quntiter", quntiter);
        intent.putExtra("frquance", frqunce);
        intent.putExtra("date_debut", detdb);
        intent.putExtra("date_fin", dtfin);
        intent.putExtra("id_pa", idp);
        intent.putExtra("idT", id);
        startActivity(intent);
    }

    public void suprrim(View view) {
        AlertDialog.Builder builderDel = new AlertDialog.Builder(view.getContext());
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        final ProgressDialog dialog = new ProgressDialog(view.getContext());
        builderDel.setTitle(nomM);



        builderDel.setMessage("Voulez-vous vraiment supprimer cet enregistrement ?");

        AlertDialog.Builder builder1 = builderDel.setPositiveButton("Oui", new DialogInterface.OnClickListener() {


            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                progressBar.setVisibility(View.VISIBLE);

                Log.d("key"," active oui");
                StringRequest request = new StringRequest(Request.Method.POST, deleteUrl, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        if (response.equalsIgnoreCase("ok")) {
                            progressBar.setVisibility(View.GONE);
                            Log.d("key","if  ok");
                            //Toast.makeText ( getApplicationContext ( ), "OK  edit", Toast.LENGTH_LONG ).show ( );


                            Intent logP = new Intent(tr_inf.this,Traitement_list.class);
                            startActivity(logP);
                            logP.putExtra("id_pa", idp);

                            Toast.makeText(tr_inf.this, "Cette Traitement est supprimer", Toast.LENGTH_SHORT).show();


                            // Log.d("APP", response);"Cette Traitement est supprimer"
                        } else {


                            Toast.makeText(tr_inf.this, "Erreur de suppresion", Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //     Log.d("APP", "ERROR = " + error);
                    }
                }) {

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("id", String.valueOf(id));
                        return params;

                    }
                };
                //requestQueue.add (request);

                //  RequestQueue.getInstance(view.getContext()).addToRequestQueue(request);
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(request);


            }
        });
        builderDel.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });


        builderDel.create().show();
    }

}