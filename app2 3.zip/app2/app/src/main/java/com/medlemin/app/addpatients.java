package com.medlemin.app;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */

public class addpatients extends Fragment implements  View.OnClickListener {

    EditText nameP, usernameP, passwordP,phoneP,comenteurP;
    Button btn_sendP;
    EditText id_m;
    globalV gv;
    private    String str_nameP,str_comenteurP,str_passwordP,str_phoneP,str_usernameP,nom;

    String url ="https://tirispress.net/pro/insertPa.php";


    public addpatients() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {   View v=inflater.inflate(R.layout.fragment_addpatients, container, false);
        btn_sendP=(Button) v.findViewById(R.id.addp);
        btn_sendP.setOnClickListener(this);
        btn_sendP = (Button) v.findViewById(R.id.addp);
        nameP = (EditText) v.findViewById(R.id.p_nom);
        comenteurP = (EditText) v.findViewById(R.id.p_comenteur);
        passwordP = (EditText) v.findViewById(R.id.p_password);
        usernameP = (EditText) v.findViewById(R.id.p_username);
        phoneP = (EditText) v.findViewById(R.id.p_phone);
        EditText id = (EditText) v.findViewById(R.id.nome_medcin);
        nom= ((globalV)getActivity().getApplication()).getNom();
        id.setText(nom);
        gv = (globalV) getActivity().getApplication();
        return v;
    }

    @Override
    public void onClick(View v) {
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Please Wait..");


        if(nameP.getText().toString().equals("")){
            Toast.makeText(getContext(), "inserer le nom", Toast.LENGTH_SHORT).show();
        }
        else if(comenteurP.getText().toString().equals("")){
            Toast.makeText(getContext(), "Enter commenteur", Toast.LENGTH_SHORT).show();
        }
        else if(passwordP.getText().toString().equals("")){
            Toast.makeText(getContext(), "Enter Password", Toast.LENGTH_SHORT).show();
        }
        else if(phoneP.getText().toString().equals("")){
            Toast.makeText(getContext(), "Enter le num du telephone", Toast.LENGTH_SHORT).show();
        }
        else if(usernameP.getText().toString().equals("")){
            Toast.makeText(getContext(), "Enter username", Toast.LENGTH_SHORT).show();
        }
        else{

            progressDialog.show();
            str_nameP = nameP.getText().toString().trim();
            str_comenteurP = comenteurP.getText().toString().trim();
            str_passwordP = passwordP.getText().toString().trim();
            str_phoneP = phoneP.getText().toString().trim();
            str_usernameP  = usernameP.getText().toString().trim();

            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    nameP.setText("");
                    comenteurP.setText("");
                    passwordP.setText("");
                    phoneP.setText("");
                    usernameP.setText("");
                    Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(getContext(), error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("id_m",nom);
                    params.put("nome",str_nameP);
                    params.put("commenteur",str_comenteurP);
                    params.put("password",str_passwordP);
                    params.put("num",str_phoneP);
                    params.put("username",str_usernameP);
                    return params;


                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            requestQueue.add(request);


        }


    }
}
