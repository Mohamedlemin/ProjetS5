package com.medlemin.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;

public class HomePage extends AppCompatActivity implements View.OnClickListener {
private CardView trtmn,rndv,add_pa,list_p,prof_med;
    globalV gv;
    TextView text;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        trtmn=(CardView)findViewById(R.id.add_tr);
        rndv=(CardView)findViewById(R.id.rndv_add_list);
        add_pa=(CardView)findViewById(R.id.addpp);
        list_p=(CardView)findViewById(R.id.listofpa);
     //   prof_med=(CardView)findViewById(R.id.profil);
      trtmn.setOnClickListener(this);
        rndv.setOnClickListener(this);
        add_pa.setOnClickListener(this);
        list_p.setOnClickListener(this);
     //  prof_med.setOnClickListener(this);
        gv=(globalV)getApplicationContext();
        TextView text = (TextView)findViewById(R.id.dr_name);
            String nom =gv.getNom();
        text.setText("Dr. "+nom);
        toolbar=findViewById(R.id.toolbar2);
       setSupportActionBar(toolbar);
       getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
       getSupportActionBar().setDisplayShowCustomEnabled(true);
       getSupportActionBar().setIcon(R.drawable.end);
       //toolbar.setLogo(R.drawable.header);
      // toolbar.setBackground(R.drawable.header);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.doctmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

                switch ( item.getItemId()){
                    case R.id.logout:
                        Intent in =new Intent(getApplicationContext(),connection.class);
                        startActivity(in);
                        break;
                }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()){
            case R.id.add_tr: i=new Intent(this,newTr.class);startActivity(i);break;
            case R.id.rndv_add_list: i=new Intent(this,newrnd.class);startActivity(i);break;
            case R.id.addpp: i=new Intent(this,ajouter_paatient.class);startActivity(i);break;
            case R.id.listofpa: i=new Intent(this,Recycle_pat.class);startActivity(i);break;
            case R.id.profil: i=new Intent(this,Medcin_profil.class);startActivity(i);break;
default:break;

        }

    }
}
