package com.medlemin.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class newTr extends AppCompatActivity {
    EditText nommedi, quantite, dated,datefin,frequance;
    int idp,idm;

    String str_nommd,str_qun,str_frq,str_use,S_datedb,S_date_fin,sr_idp,sr_idm;
  //  gv = (globalV) getActivity().getApplication();
    String url ="https://tirispress.net/pro/addTr.php";
    ProgressBar pb;
    globalV gv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_tr);

        nommedi = findViewById(R.id.nmdic);
        quantite =findViewById(R.id.quntmedc);
        dated=findViewById(R.id.dated);
        datefin = findViewById(R.id.datefin);
        frequance = findViewById(R.id.frqc);
         idp = getIntent().getIntExtra("id_pa",0);
        idm= getIntent().getIntExtra("id_m",0);
       // idp=findViewById(R.id.idpaaa);
       // idm=findViewById(R.id.idmmm);

        gv=(globalV)getApplicationContext();

    }

    public void addtr(View view) {


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");
        Log.d("key","enrgstrer valid!");

        if(nommedi.getText().toString().equals("")){
            Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
        }
        else if(quantite.getText().toString().equals("")){
            Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
        }
        else if(dated.getText().toString().equals("")){
            Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
        }
        else if(datefin.getText().toString().equals("")){
            Toast.makeText(this, "champs vide!", Toast.LENGTH_SHORT).show();
        }
        else{

            progressDialog.show();
            str_nommd = nommedi.getText().toString().trim();
            str_qun = quantite.getText().toString().trim();
            str_frq = frequance.getText().toString().trim();
           // str_use = use.getText().toString().trim();
            S_datedb = dated.getText().toString().trim();
            S_date_fin = datefin.getText().toString().trim();
            // idp=gv.getId();
            // idm=gv.getId_m();

            Log.d("key","les donner!"+idm+" "+idp);
            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    nommedi.setText("");
                    quantite.setText("");
                    frequance.setText("");
                  //  use.setText("");
                    Toast.makeText(newTr.this, response, Toast.LENGTH_SHORT).show();
                    Log.d("key","onresponse valid!");
                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Log.d("key","OnError valid!"+error.getCause().getMessage());
                    Toast.makeText(newTr.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();

                    params.put("nmdc",str_nommd);
                    params.put("qunt",str_qun);
                    params.put("frq",str_frq);
                 //   params.put("use",str_use);
                    params.put("datd",S_datedb);
                    params.put("datf",S_date_fin);
                    params.put("idm", String.valueOf(idm));
                    params.put("idp", String.valueOf(idp));

                    return params;



                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(newTr.this);
            requestQueue.add(request);


        }
    }
}
